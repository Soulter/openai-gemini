帮我写一个python后端，fastapi, 用于接收请求，并且根据请求修改 ~/.openclaw/openclaw.json。

## 接口 1 

POST /api/v1/channels