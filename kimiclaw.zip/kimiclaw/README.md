# Shell

This app is used to config openclaw.

Add feishu config:

```bash
jq '.channels.feishu = {
  "enabled": true,
  "appId": "APPID",
  "appSecret": "APPSECRET",
  "domain": "feishu",
  "groupPolicy": "open"
}' /root/.openclaw/openclaw.json > /tmp/openclaw.json && mv /tmp/openclaw.json /root/.openclaw/openclaw.json
```

Remember to restart gateway

```bash
systemctl --user restart openclaw-gateway
```
