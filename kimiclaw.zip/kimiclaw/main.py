import subprocess
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class ShellCommand(BaseModel):
    command: str
    timeout: int | None = 60


class ShellResponse(BaseModel):
    stdout: str
    stderr: str
    returncode: int


@app.post("/shell", response_model=ShellResponse)
async def execute_shell(cmd: ShellCommand) -> ShellResponse:
    """Execute a shell command and return the result."""
    try:
        result = subprocess.run(
            cmd.command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=cmd.timeout,
        )
        return ShellResponse(
            stdout=result.stdout,
            stderr=result.stderr,
            returncode=result.returncode,
        )
    except subprocess.TimeoutExpired:
        return ShellResponse(
            stdout="",
            stderr=f"Command timed out after {cmd.timeout} seconds",
            returncode=-1,
        )
